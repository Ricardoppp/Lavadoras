<?php
include 'validar.php';

$nombre=$_POST['nombre_producto'];
$serial=$_POST['seriales'];
$cantidad=$_POST['cantidad'];
$color=$_POST['color'];




$sql = "INSERT INTO inventario (nombre, serial , cantidad, color)
VALUES ('$nombre', '$serial', '$cantidad', '$color')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
  
  mysqli_close($conn);


?>